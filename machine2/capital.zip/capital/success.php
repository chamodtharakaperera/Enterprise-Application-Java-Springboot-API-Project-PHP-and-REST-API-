<html>
<head>

</head>
<body>
Your Request Data Inserted Successfully! Our assistance team will reach you..
<br/><br/>
<br/><br/>
<a href="index.php">Return Home</a>
</body>
</html>