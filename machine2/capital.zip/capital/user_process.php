<?php
include("dbconnect.php");

$cname=$_REQUEST['cusName'];
$addr=$_REQUEST['address'];
$hotline=$_REQUEST['phone'];
$purchaseNo=$_REQUEST['PONo'];
$model=$_REQUEST['modelNo'];
$prodName=$_REQUEST['proName'];
$prodDesc=$_REQUEST['prodesc'];
$day=$_REQUEST['day'];
$month=$_REQUEST['month'];
$year=$_REQUEST['year'];
$problemDesc=$_REQUEST['probdesc'];

//Inserting data to the table

$query=mysqli_query($db_connect,"INSERT INTO customerinfo(cusName,address,phone,PONo) VALUES('$cname','$addr','$hotline','$purchaseNo')") or die(mysqli_error($db_connect));
//$cnofetch=mysqli_query($db_connect,"SELECT cusNo FROM customerinfo ORDER by cusNo DESC LIMIT 1;") or die(mysqli_error($db_connect));
$query_run=mysqli_query($db_connect,"SELECT cusNo FROM customerinfo ORDER by cusNo DESC LIMIT 1;");
while($row=mysqli_fetch_array($query_run))
{
	$datas=$row[0];
}


$query=mysqli_query($db_connect,"INSERT INTO productinfo(modelNo,cusNo,proName,proDesc,DOPurchase,probdesc) VALUES('$model','$datas','$prodName','$prodDesc',concat('$day','$month','$year'),'$problemDesc')") or die(mysqli_error($db_connect));

mysqli_close($db_connect);

header("location:success.php");
?>