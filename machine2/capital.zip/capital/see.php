<html>
<body>
	
	<h1>Customer Maintenance Requests</h1>
<form>
	<table border="2px">
	<tr>
		<th>Customer Number</th>;
		<th>Customer Name</th>;
		<th>Address&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>;
		<th>Phone&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>;
		<th>Purchase Order No</th>;
		<th>Model No&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>;
		<th>Product Name</th>;
		<th>Problem Description&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>;
	</tr>
<?php  
include("dbconnect.php");
$query="SELECT customerinfo.cusNo,customerinfo.cusName,customerinfo.address,customerinfo.phone,customerinfo.poNo,productinfo.modelNo,productinfo.proName,productinfo.probDesc FROM customerinfo INNER JOIN productinfo ON customerinfo.cusNo=productinfo.cusNo";
$query_run=mysqli_query($db_connect,$query);
while($row=mysqli_fetch_array($query_run))
{
	$prodesq="prodesc";
	$customerNo=$row['cusNo'];
	$customerName=$row['cusName'];
	$addr=$row['address'];
	$hot=$row['phone'];
	$po=$row['poNo'];
	$model= $row['modelNo'];
	$proName=$row['proName'];
	$prodes=$row['probDesc'];
	?>
	

	<tr>
		<td><?php echo"$customerNo" ?></td>
		<td><?php echo "$customerName" ?></td>
		<td><?php echo "$addr" ?></td>
		<td><?php echo "$hot" ?></td>
		<td><?php echo "$po" ?></td>
		<td><?php echo "$model" ?></td>
		<td><?php echo "$proName" ?></td>
		<td><?php echo "$prodes" ?></td>
	</tr>
<?php
}
?>
	
</table>
</form>
</body>
</html>